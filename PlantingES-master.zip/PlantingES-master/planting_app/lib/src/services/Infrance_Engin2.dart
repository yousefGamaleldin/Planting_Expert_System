import 'dart:core';
import 'package:flutter/material.dart';


class Infrance{
  Infrance({String plantType, double width , double height , int color, String goal}){
    //print(result)"what are you planting");
    // int color=5;
    // int width=21;
    // int height=10;
    // String goal="N//A";
    // String plantType="boklyat";
    double minwidth;
    double maxwidth;
    double minheight;
    double maxheight;
    String result = "N//A";
    if (plantType=='')
    {

      if (width <= maxwidth)//bigest posible width
      {
        if (height<=maxheight)
        {
          if (color==3)
          {
            if (goal=="N//A")
            {
              print ("a");
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="samara kter")
            {
              print (result);
            }
          }
          if (color==4)
          {
            if (goal=="aksb")
            {
              print (5);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }

        }
        if (height >= minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height < minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print (result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height > maxheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
      }
      if (width >= minwidth)//2
      {
        if (height<=maxheight)
        {
          if (color==3)
          {
            if (goal=="N//A")
            {
              print (result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal==result)
            {
              print (result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print (5);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }

        }
        if (height >= minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height < minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print (result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height > maxheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
      }
      if (width > maxwidth)//3
      {
        if (height<=maxheight)
        {
          if (color==3)
          {
            if (goal=="N//A")
            {
              print (result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print (result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print (5);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }

        }
        if (height >= minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height < minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print ("arz3");
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height > maxheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="ad5m")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
      }
      if (width < minwidth)//4
      {
        if (height <= maxheight)
        {
          if (color==3)
          {
            if (goal=="assd")
            {
              print (result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="samara kter")
            {
              print (result);
            }
          }
          if (color==4)
          {
            if (goal=="aksb")
            {
              print (5);
            }
          }
          if (color==5)
          {
            if (goal=="N//A awy")
            {
              print(result);
            }
          }

        }
        if (height >= minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="ad5m")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height < minheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="N//A")
            {
              print ("arz3");
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
        if (height > maxheight)
        {
          if (color==1)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==2)
          {
            if (goal=="N//A1")
            {
              print(result);
            }
          }
          if (color==3)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          if (color==4)
          {
            if (goal=="ad5m")
            {
              print(result);
            }
          }
          if (color==5)
          {
            if (goal=="N//A")
            {
              print(result);
            }
          }
          
        }
      }
      
    }
    

  }
}


// int main()
// {

// ContuingEngin();



// }